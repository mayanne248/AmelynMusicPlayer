import React from 'react';
import { Book as BookIcon, Calendar, FileText, Trash2, Eye, Star, Heart } from 'lucide-react';
import { Book } from '../types/Book';

interface BookCardProps {
  book: Book;
  onOpen: (book: Book) => void;
  onDelete: (id: string) => void;
  viewMode?: 'grid' | 'list';
  showProgress?: boolean;
}

export const BookCard: React.FC<BookCardProps> = ({ 
  book, 
  onOpen, 
  onDelete, 
  viewMode = 'grid',
  showProgress = false 
}) => {
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const getProgressPercentage = () => {
    if (!book.readingProgress) return 0;
    return (book.readingProgress.currentPage / book.readingProgress.totalPages) * 100;
  };

  if (viewMode === 'list') {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 hover:shadow-md transition-shadow">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-20 bg-gradient-to-br from-amber-100 to-amber-200 rounded-lg flex-shrink-0 overflow-hidden">
            {book.coverImage ? (
              <img src={book.coverImage} alt={book.title} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <BookIcon className="w-6 h-6 text-amber-600" />
              </div>
            )}
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between">
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-gray-800 text-lg truncate">{book.title}</h3>
                <p className="text-gray-600 text-sm">{book.author}</p>
                {book.genre && (
                  <span className="inline-block px-2 py-1 bg-amber-100 text-amber-700 text-xs rounded-full mt-1">
                    {book.genre}
                  </span>
                )}
              </div>
              
              <div className="flex items-center space-x-2 ml-4">
                {book.isFavorite && <Heart className="w-4 h-4 text-red-500 fill-current" />}
                {book.rating && (
                  <div className="flex items-center">
                    <Star className="w-4 h-4 text-yellow-500 fill-current" />
                    <span className="text-sm text-gray-600 ml-1">{book.rating}</span>
                  </div>
                )}
                <button
                  onClick={() => onOpen(book)}
                  className="p-2 bg-amber-100 text-amber-700 rounded-lg hover:bg-amber-200 transition-colors"
                >
                  <Eye className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onDelete(book.id)}
                  className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
            
            {showProgress && book.readingProgress && (
              <div className="mt-2">
                <div className="flex justify-between text-xs text-gray-600 mb-1">
                  <span>Page {book.readingProgress.currentPage} of {book.readingProgress.totalPages}</span>
                  <span>{Math.round(getProgressPercentage())}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-1.5">
                  <div 
                    className="bg-amber-600 h-1.5 rounded-full transition-all duration-300"
                    style={{ width: `${getProgressPercentage()}%` }}
                  />
                </div>
              </div>
            )}
            
            <div className="flex items-center justify-between text-xs text-gray-500 mt-2">
              <div className="flex items-center">
                <Calendar className="w-3 h-3 mr-1" />
                {formatDate(book.uploadDate)}
              </div>
              <div className="flex items-center">
                <FileText className="w-3 h-3 mr-1" />
                {book.pageCount} pages
              </div>
              <div>{formatFileSize(book.fileSize)}</div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="group relative bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 overflow-hidden">
      <div className="aspect-[3/4] bg-gradient-to-br from-amber-100 to-amber-200 relative overflow-hidden">
        {book.coverImage ? (
          <img
            src={book.coverImage}
            alt={book.title}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <BookIcon className="w-16 h-16 text-amber-600" />
          </div>
        )}
        
        {/* Favorite indicator */}
        {book.isFavorite && (
          <div className="absolute top-2 right-2">
            <Heart className="w-5 h-5 text-red-500 fill-current" />
          </div>
        )}
        
        {/* Overlay with actions */}
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all duration-300 flex items-center justify-center">
          <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex space-x-2">
            <button
              onClick={() => onOpen(book)}
              className="p-3 bg-white rounded-full hover:bg-gray-100 transition-colors"
              title="Open Book"
            >
              <Eye className="w-5 h-5 text-gray-700" />
            </button>
            <button
              onClick={() => onDelete(book.id)}
              className="p-3 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors"
              title="Delete Book"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="font-semibold text-gray-800 text-lg mb-1 line-clamp-2 leading-tight">
          {book.title}
        </h3>
        <p className="text-gray-600 text-sm mb-2">{book.author}</p>
        
        {book.genre && (
          <span className="inline-block px-2 py-1 bg-amber-100 text-amber-700 text-xs rounded-full mb-2">
            {book.genre}
          </span>
        )}
        
        {book.rating && (
          <div className="flex items-center mb-2">
            <Star className="w-4 h-4 text-yellow-500 fill-current" />
            <span className="text-sm text-gray-600 ml-1">{book.rating}/5</span>
          </div>
        )}
        
        {showProgress && book.readingProgress && (
          <div className="mb-3">
            <div className="flex justify-between text-xs text-gray-600 mb-1">
              <span>Page {book.readingProgress.currentPage}</span>
              <span>{Math.round(getProgressPercentage())}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-1.5">
              <div 
                className="bg-amber-600 h-1.5 rounded-full transition-all duration-300"
                style={{ width: `${getProgressPercentage()}%` }}
              />
            </div>
          </div>
        )}
        
        <div className="flex items-center justify-between text-xs text-gray-500">
          <div className="flex items-center">
            <Calendar className="w-3 h-3 mr-1" />
            {formatDate(book.uploadDate)}
          </div>
          <div className="flex items-center">
            <FileText className="w-3 h-3 mr-1" />
            {book.pageCount} pages
          </div>
        </div>
        
        <div className="mt-2 text-xs text-gray-500">
          {formatFileSize(book.fileSize)}
        </div>
      </div>
    </div>
  );
};