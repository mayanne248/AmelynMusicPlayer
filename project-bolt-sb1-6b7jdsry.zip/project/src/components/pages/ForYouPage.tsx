import React from 'react';
import { Book, Clock, Target, TrendingUp, BookOpen } from 'lucide-react';
import { Book as BookType } from '../../types/Book';
import { BookCarousel } from '../BookCarousel';
import { useReadingProgress } from '../../hooks/useReadingProgress';

interface ForYouPageProps {
  books: BookType[];
  onOpenBook: (book: BookType) => void;
  onDeleteBook: (id: string) => void;
}

export const ForYouPage: React.FC<ForYouPageProps> = ({
  books,
  onOpenBook,
  onDeleteBook,
}) => {
  const { getTodaysProgress } = useReadingProgress();
  const todaysProgress = getTodaysProgress();

  const continueReading = books.filter(book => 
    book.readingProgress && 
    book.readingProgress.currentPage > 0 && 
    !book.readingProgress.isCompleted
  ).slice(0, 5);

  const recentlyAdded = books
    .sort((a, b) => new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime())
    .slice(0, 8);

  const recommendations = books
    .filter(book => book.rating && book.rating >= 4)
    .slice(0, 6);

  return (
    <div className="space-y-8">
      {/* Welcome Header */}
      <div className="bg-gradient-to-r from-amber-500 to-orange-500 rounded-2xl p-8 text-white">
        <h1 className="text-3xl font-bold mb-2">Welcome back!</h1>
        <p className="text-amber-100 text-lg">Ready to continue your reading journey?</p>
      </div>

      {/* Reading Progress */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-800">Today's Goal</h3>
            <Clock className="w-5 h-5 text-amber-600" />
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">{todaysProgress.current} / {todaysProgress.goal} minutes</span>
              <span className="text-amber-600 font-medium">{Math.round(todaysProgress.percentage)}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-amber-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${Math.min(todaysProgress.percentage, 100)}%` }}
              />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-800">Books Read</h3>
            <BookOpen className="w-5 h-5 text-green-600" />
          </div>
          <div className="text-2xl font-bold text-gray-800">
            {books.filter(b => b.readingProgress?.isCompleted).length}
          </div>
          <p className="text-sm text-gray-600">This month</p>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-800">Reading Streak</h3>
            <TrendingUp className="w-5 h-5 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-gray-800">7</div>
          <p className="text-sm text-gray-600">Days in a row</p>
        </div>
      </div>

      {/* Continue Reading */}
      {continueReading.length > 0 && (
        <section>
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Continue Reading</h2>
          <BookCarousel
            books={continueReading}
            onOpenBook={onOpenBook}
            onDeleteBook={onDeleteBook}
            showProgress={true}
          />
        </section>
      )}

      {/* Recently Added */}
      {recentlyAdded.length > 0 && (
        <section>
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Recently Added</h2>
          <BookCarousel
            books={recentlyAdded}
            onOpenBook={onOpenBook}
            onDeleteBook={onDeleteBook}
          />
        </section>
      )}

      {/* Recommendations */}
      {recommendations.length > 0 && (
        <section>
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Recommended for You</h2>
          <BookCarousel
            books={recommendations}
            onOpenBook={onOpenBook}
            onDeleteBook={onDeleteBook}
          />
        </section>
      )}

      {/* Empty State */}
      {books.length === 0 && (
        <div className="text-center py-16">
          <div className="w-24 h-24 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Book className="w-12 h-12 text-amber-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Start Your Reading Journey</h2>
          <p className="text-gray-600 max-w-md mx-auto">
            Upload your first book to get personalized recommendations and track your reading progress.
          </p>
        </div>
      )}
    </div>
  );
};