import React, { useState, useMemo } from 'react';
import { Plus, Filter, Grid, List, BookOpen, Clock, Star } from 'lucide-react';
import { Book } from '../../types/Book';
import { BookUpload } from '../BookUpload';
import { BookCard } from '../BookCard';
import { SearchBar } from '../SearchBar';

interface LibraryPageProps {
  books: Book[];
  onAddBook: (book: Book) => void;
  onOpenBook: (book: Book) => void;
  onDeleteBook: (id: string) => void;
}

const FILTER_OPTIONS = [
  { value: 'all', label: 'All Books' },
  { value: 'reading', label: 'Currently Reading' },
  { value: 'completed', label: 'Completed' },
  { value: 'favorites', label: 'Favorites' },
  { value: 'unread', label: 'Unread' },
];

export const LibraryPage: React.FC<LibraryPageProps> = ({
  books,
  onAddBook,
  onOpenBook,
  onDeleteBook,
}) => {
  const [showUpload, setShowUpload] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterBy, setFilterBy] = useState('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const filteredBooks = useMemo(() => {
    let filtered = books;

    // Apply search filter
    if (searchQuery) {
      filtered = filtered.filter(book =>
        book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (book.author && book.author.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    // Apply status filter
    switch (filterBy) {
      case 'reading':
        filtered = filtered.filter(book => 
          book.readingProgress && 
          book.readingProgress.currentPage > 0 && 
          !book.readingProgress.isCompleted
        );
        break;
      case 'completed':
        filtered = filtered.filter(book => 
          book.readingProgress?.isCompleted
        );
        break;
      case 'favorites':
        filtered = filtered.filter(book => book.isFavorite);
        break;
      case 'unread':
        filtered = filtered.filter(book => 
          !book.readingProgress || book.readingProgress.currentPage === 0
        );
        break;
    }

    return filtered;
  }, [books, searchQuery, filterBy]);

  const stats = {
    total: books.length,
    reading: books.filter(b => b.readingProgress && b.readingProgress.currentPage > 0 && !b.readingProgress.isCompleted).length,
    completed: books.filter(b => b.readingProgress?.isCompleted).length,
    favorites: books.filter(b => b.isFavorite).length,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">My Library</h1>
          <p className="text-gray-600">{books.length} books in your collection</p>
        </div>
        <button
          onClick={() => setShowUpload(true)}
          className="flex items-center space-x-2 px-6 py-3 bg-amber-600 text-white rounded-xl hover:bg-amber-700 transition-colors shadow-lg hover:shadow-xl transform hover:scale-105 duration-200"
        >
          <Plus className="w-5 h-5" />
          <span>Add Books</span>
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-4 border border-gray-100">
          <div className="flex items-center space-x-2 mb-2">
            <BookOpen className="w-4 h-4 text-blue-600" />
            <span className="text-sm font-medium text-gray-600">Total Books</span>
          </div>
          <div className="text-2xl font-bold text-gray-800">{stats.total}</div>
        </div>
        <div className="bg-white rounded-xl p-4 border border-gray-100">
          <div className="flex items-center space-x-2 mb-2">
            <Clock className="w-4 h-4 text-orange-600" />
            <span className="text-sm font-medium text-gray-600">Reading</span>
          </div>
          <div className="text-2xl font-bold text-gray-800">{stats.reading}</div>
        </div>
        <div className="bg-white rounded-xl p-4 border border-gray-100">
          <div className="flex items-center space-x-2 mb-2">
            <BookOpen className="w-4 h-4 text-green-600" />
            <span className="text-sm font-medium text-gray-600">Completed</span>
          </div>
          <div className="text-2xl font-bold text-gray-800">{stats.completed}</div>
        </div>
        <div className="bg-white rounded-xl p-4 border border-gray-100">
          <div className="flex items-center space-x-2 mb-2">
            <Star className="w-4 h-4 text-yellow-600" />
            <span className="text-sm font-medium text-gray-600">Favorites</span>
          </div>
          <div className="text-2xl font-bold text-gray-800">{stats.favorites}</div>
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <SearchBar
            value={searchQuery}
            onChange={setSearchQuery}
            placeholder="Search your library..."
          />
        </div>
        <div className="flex items-center space-x-2">
          <select
            value={filterBy}
            onChange={(e) => setFilterBy(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
          >
            {FILTER_OPTIONS.map(option => (
              <option key={option.value} value={option.value}>{option.label}</option>
            ))}
          </select>
          <div className="flex border border-gray-300 rounded-lg overflow-hidden">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 ${viewMode === 'grid' ? 'bg-amber-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50'}`}
            >
              <Grid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 ${viewMode === 'list' ? 'bg-amber-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50'}`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Books Display */}
      {filteredBooks.length > 0 ? (
        <div className={viewMode === 'grid' 
          ? "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6"
          : "space-y-4"
        }>
          {filteredBooks.map((book) => (
            <BookCard
              key={book.id}
              book={book}
              onOpen={onOpenBook}
              onDelete={onDeleteBook}
              viewMode={viewMode}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <BookOpen className="w-12 h-12 text-gray-400" />
          </div>
          <h3 className="text-xl font-semibold text-gray-800 mb-2">
            {books.length === 0 ? 'No books in your library' : 'No books match your filters'}
          </h3>
          <p className="text-gray-600 mb-6">
            {books.length === 0 
              ? 'Start building your digital library by uploading your first book.'
              : 'Try adjusting your search or filter settings.'
            }
          </p>
          {books.length === 0 && (
            <button
              onClick={() => setShowUpload(true)}
              className="inline-flex items-center px-6 py-3 bg-amber-600 text-white rounded-xl hover:bg-amber-700 transition-colors"
            >
              <Plus className="w-5 h-5 mr-2" />
              Upload Your First Book
            </button>
          )}
        </div>
      )}

      {/* Upload Modal */}
      {showUpload && (
        <BookUpload
          onUpload={onAddBook}
          onClose={() => setShowUpload(false)}
        />
      )}
    </div>
  );
};