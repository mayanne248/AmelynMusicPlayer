import React, { useCallback, useState } from 'react';
import { Upload, FileText, X } from 'lucide-react';
import { Book } from '../types/Book';
import { fileToBase64, generatePdfThumbnail, getPdfPageCount } from '../utils/pdfUtils';

interface BookUploadProps {
  onUpload: (book: Book) => void;
  onClose: () => void;
}

export const BookUpload: React.FC<BookUploadProps> = ({ onUpload, onClose }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    const pdfFiles = files.filter(file => file.type === 'application/pdf');
    
    if (pdfFiles.length > 0) {
      handleFiles(pdfFiles);
    }
  }, []);

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    handleFiles(files);
  };

  const handleFiles = async (files: File[]) => {
    setUploading(true);
    
    for (const file of files) {
      try {
        const fileData = await fileToBase64(file);
        const coverImage = await generatePdfThumbnail(fileData);
        const pageCount = await getPdfPageCount(fileData);
        
        const book: Book = {
          id: Date.now().toString() + Math.random(),
          title: title || file.name.replace('.pdf', ''),
          author: author || 'Unknown Author',
          uploadDate: new Date().toISOString(),
          fileData,
          coverImage,
          pageCount,
          fileSize: file.size,
        };
        
        onUpload(book);
      } catch (error) {
        console.error('Error processing file:', error);
        alert(`Error processing ${file.name}. Please try again.`);
      }
    }
    
    setUploading(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between p-6 border-b">
          <h3 className="text-xl font-semibold text-gray-800">Upload Books</h3>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-6">
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Book Title (optional)
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
              placeholder="Enter book title..."
            />
          </div>
          
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Author (optional)
            </label>
            <input
              type="text"
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
              placeholder="Enter author name..."
            />
          </div>
          
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              isDragging
                ? 'border-amber-500 bg-amber-50'
                : 'border-gray-300 hover:border-amber-400'
            }`}
            onDrop={handleDrop}
            onDragOver={(e) => e.preventDefault()}
            onDragEnter={() => setIsDragging(true)}
            onDragLeave={() => setIsDragging(false)}
          >
            {uploading ? (
              <div className="flex flex-col items-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-amber-600 mb-4"></div>
                <p className="text-gray-600">Processing PDF...</p>
              </div>
            ) : (
              <>
                <div className="flex justify-center mb-4">
                  <div className="p-3 bg-amber-100 rounded-full">
                    <Upload className="w-8 h-8 text-amber-600" />
                  </div>
                </div>
                <p className="text-lg font-medium text-gray-800 mb-2">
                  Drop PDF files here
                </p>
                <p className="text-gray-600 mb-4">or click to browse</p>
                <input
                  type="file"
                  multiple
                  accept=".pdf"
                  onChange={handleFileInput}
                  className="hidden"
                  id="file-input"
                />
                <label
                  htmlFor="file-input"
                  className="inline-flex items-center px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors cursor-pointer"
                >
                  <FileText className="w-4 h-4 mr-2" />
                  Choose Files
                </label>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};