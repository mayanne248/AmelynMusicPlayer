import React, { useState, useEffect } from 'react';
import { X, ChevronLeft, ChevronRight, ZoomIn, ZoomOut, Settings } from 'lucide-react';
import { Book } from '../types/Book';
import { UserSettings } from '../types/Book';
import * as pdfjsLib from 'pdfjs-dist';

interface PDFViewerProps {
  book: Book;
  onClose: () => void;
  onUpdateProgress?: (bookId: string, currentPage: number, totalPages: number) => void;
  settings: UserSettings['reading'];
}

export const PDFViewer: React.FC<PDFViewerProps> = ({ 
  book, 
  onClose, 
  onUpdateProgress,
  settings 
}) => {
  const [currentPage, setCurrentPage] = useState(book.readingProgress?.currentPage || 1);
  const [totalPages, setTotalPages] = useState(0);
  const [scale, setScale] = useState(1.2);
  const [loading, setLoading] = useState(true);
  const [pdfDoc, setPdfDoc] = useState<any>(null);
  const [showSettings, setShowSettings] = useState(false);

  useEffect(() => {
    loadPDF();
  }, [book]);

  useEffect(() => {
    if (pdfDoc) {
      renderPage(currentPage);
      // Auto-save progress if enabled
      if (settings.autoSave && onUpdateProgress) {
        onUpdateProgress(book.id, currentPage, totalPages);
      }
    }
  }, [pdfDoc, currentPage, scale, settings.autoSave]);

  const loadPDF = async () => {
    try {
      setLoading(true);
      const loadingTask = pdfjsLib.getDocument({ data: atob(book.fileData) });
      const pdf = await loadingTask.promise;
      setPdfDoc(pdf);
      setTotalPages(pdf.numPages);
      setLoading(false);
    } catch (error) {
      console.error('Error loading PDF:', error);
      setLoading(false);
    }
  };

  const renderPage = async (pageNum: number) => {
    if (!pdfDoc) return;

    try {
      const page = await pdfDoc.getPage(pageNum);
      const viewport = page.getViewport({ scale });
      
      const canvas = document.getElementById('pdf-canvas') as HTMLCanvasElement;
      if (!canvas) return;
      
      const context = canvas.getContext('2d');
      canvas.height = viewport.height;
      canvas.width = viewport.width;
      
      // Apply reading settings
      if (settings.nightMode) {
        context.fillStyle = settings.backgroundColor;
        context.fillRect(0, 0, canvas.width, canvas.height);
      }
      
      await page.render({
        canvasContext: context,
        viewport: viewport,
      }).promise;
    } catch (error) {
      console.error('Error rendering page:', error);
    }
  };

  const goToPage = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  const zoomIn = () => {
    if (scale < 3) {
      setScale(scale + 0.2);
    }
  };

  const zoomOut = () => {
    if (scale > 0.5) {
      setScale(scale - 0.2);
    }
  };

  const handleClose = () => {
    // Save progress before closing
    if (onUpdateProgress) {
      onUpdateProgress(book.id, currentPage, totalPages);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-90 z-50 flex flex-col">
      {/* Header */}
      <div className={`border-b px-6 py-4 flex items-center justify-between ${
        settings.nightMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'
      }`}>
        <div>
          <h2 className={`text-xl font-semibold ${settings.nightMode ? 'text-white' : 'text-gray-800'}`}>
            {book.title}
          </h2>
          <p className={`${settings.nightMode ? 'text-gray-300' : 'text-gray-600'}`}>
            {book.author}
          </p>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Page Controls */}
          <div className="flex items-center space-x-2">
            <button
              onClick={() => goToPage(currentPage - 1)}
              disabled={currentPage <= 1}
              className={`p-2 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
                settings.nightMode 
                  ? 'bg-gray-700 hover:bg-gray-600 text-white' 
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
              }`}
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            
            <span className={`text-sm min-w-0 ${settings.nightMode ? 'text-gray-300' : 'text-gray-600'}`}>
              {currentPage} of {totalPages}
            </span>
            
            <button
              onClick={() => goToPage(currentPage + 1)}
              disabled={currentPage >= totalPages}
              className={`p-2 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
                settings.nightMode 
                  ? 'bg-gray-700 hover:bg-gray-600 text-white' 
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
              }`}
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          
          {/* Zoom Controls */}
          <div className="flex items-center space-x-2">
            <button
              onClick={zoomOut}
              className={`p-2 rounded-lg transition-colors ${
                settings.nightMode 
                  ? 'bg-gray-700 hover:bg-gray-600 text-white' 
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
              }`}
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            
            <span className={`text-sm min-w-0 ${settings.nightMode ? 'text-gray-300' : 'text-gray-600'}`}>
              {Math.round(scale * 100)}%
            </span>
            
            <button
              onClick={zoomIn}
              className={`p-2 rounded-lg transition-colors ${
                settings.nightMode 
                  ? 'bg-gray-700 hover:bg-gray-600 text-white' 
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
              }`}
            >
              <ZoomIn className="w-4 h-4" />
            </button>
          </div>

          {/* Settings */}
          <button
            onClick={() => setShowSettings(!showSettings)}
            className={`p-2 rounded-lg transition-colors ${
              settings.nightMode 
                ? 'bg-gray-700 hover:bg-gray-600 text-white' 
                : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
            }`}
          >
            <Settings className="w-4 h-4" />
          </button>
          
          <button
            onClick={handleClose}
            className="p-2 rounded-lg bg-red-100 hover:bg-red-200 text-red-600 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Reading Progress */}
      <div className={`px-6 py-2 border-b ${
        settings.nightMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
      }`}>
        <div className="flex items-center justify-between text-sm">
          <span className={settings.nightMode ? 'text-gray-300' : 'text-gray-600'}>
            Reading Progress: {Math.round((currentPage / totalPages) * 100)}%
          </span>
          <div className="w-32 bg-gray-200 rounded-full h-1.5">
            <div 
              className="bg-amber-600 h-1.5 rounded-full transition-all duration-300"
              style={{ width: `${(currentPage / totalPages) * 100}%` }}
            />
          </div>
        </div>
      </div>
      
      {/* PDF Content */}
      <div className={`flex-1 overflow-auto flex items-center justify-center p-4 ${
        settings.nightMode ? 'bg-gray-900' : 'bg-gray-100'
      }`}>
        {loading ? (
          <div className="flex flex-col items-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-amber-600 mb-4"></div>
            <p className={settings.nightMode ? 'text-gray-300' : 'text-gray-600'}>Loading PDF...</p>
          </div>
        ) : (
          <div className="bg-white shadow-2xl">
            <canvas
              id="pdf-canvas"
              className="max-w-full max-h-full"
              style={{
                fontFamily: settings.fontFamily,
                fontSize: `${settings.fontSize}px`,
                lineHeight: settings.lineHeight,
                backgroundColor: settings.backgroundColor,
                color: settings.textColor,
              }}
            />
          </div>
        )}
      </div>
    </div>
  );
};