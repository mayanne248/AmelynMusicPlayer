import React from 'react';
import { Home, Compass, Library, Settings, User } from 'lucide-react';
import { PageType } from '../types/Navigation';

interface NavigationProps {
  currentPage: PageType;
  onNavigate: (page: PageType) => void;
  profilePicture?: string;
  userName: string;
}

export const Navigation: React.FC<NavigationProps> = ({
  currentPage,
  onNavigate,
  profilePicture,
  userName,
}) => {
  const navItems = [
    { id: 'for-you' as PageType, label: 'For You', icon: Home },
    { id: 'explore' as PageType, label: 'Explore', icon: Compass },
    { id: 'library' as PageType, label: 'My Library', icon: Library },
    { id: 'settings' as PageType, label: 'Settings', icon: Settings },
  ];

  return (
    <nav className="bg-white border-r border-gray-200 w-64 h-full flex flex-col">
      {/* Profile Section */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center overflow-hidden">
            {profilePicture ? (
              <img src={profilePicture} alt={userName} className="w-full h-full object-cover" />
            ) : (
              <User className="w-6 h-6 text-white" />
            )}
          </div>
          <div>
            <h3 className="font-semibold text-gray-800">{userName}</h3>
            <p className="text-sm text-gray-600">Book Enthusiast</p>
          </div>
        </div>
      </div>

      {/* Navigation Items */}
      <div className="flex-1 py-6">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center space-x-3 px-6 py-3 text-left transition-colors ${
                isActive
                  ? 'bg-amber-50 text-amber-700 border-r-2 border-amber-600'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-800'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'text-amber-600' : ''}`} />
              <span className="font-medium">{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Footer */}
      <div className="p-6 border-t border-gray-200">
        <div className="text-center">
          <div className="w-8 h-8 mx-auto mb-2 bg-amber-600 rounded-lg flex items-center justify-center">
            <Library className="w-4 h-4 text-white" />
          </div>
          <p className="text-xs text-gray-500">Digital Library v2.0</p>
        </div>
      </div>
    </nav>
  );
};