import { useState, useEffect } from 'react';
import { UserSettings } from '../types/Book';

const DEFAULT_SETTINGS: UserSettings = {
  profile: {
    name: 'Book Lover',
    email: '',
    joinDate: new Date().toISOString(),
  },
  reading: {
    fontSize: 16,
    fontFamily: 'Inter',
    backgroundColor: '#ffffff',
    textColor: '#1f2937',
    lineHeight: 1.6,
    pageTransition: 'slide',
    autoSave: true,
    nightMode: false,
  },
  notifications: {
    readingReminders: true,
    newBookAlerts: true,
    goalReminders: true,
    emailNotifications: false,
  },
  privacy: {
    shareReadingActivity: false,
    allowRecommendations: true,
    dataCollection: false,
  },
  goals: {
    dailyReadingMinutes: 30,
    monthlyBookTarget: 2,
    yearlyBookTarget: 24,
  },
};

const SETTINGS_KEY = 'digital-library-settings';

export const useSettings = () => {
  const [settings, setSettings] = useState<UserSettings>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = () => {
    try {
      const stored = localStorage.getItem(SETTINGS_KEY);
      if (stored) {
        const parsedSettings = JSON.parse(stored);
        setSettings({ ...DEFAULT_SETTINGS, ...parsedSettings });
      }
    } catch (error) {
      console.error('Error loading settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateSettings = (updates: Partial<UserSettings>) => {
    const newSettings = { ...settings, ...updates };
    setSettings(newSettings);
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(newSettings));
    } catch (error) {
      console.error('Error saving settings:', error);
    }
  };

  const updateProfile = (profileUpdates: Partial<UserSettings['profile']>) => {
    updateSettings({
      profile: { ...settings.profile, ...profileUpdates }
    });
  };

  const updateReadingSettings = (readingUpdates: Partial<UserSettings['reading']>) => {
    updateSettings({
      reading: { ...settings.reading, ...readingUpdates }
    });
  };

  return {
    settings,
    loading,
    updateSettings,
    updateProfile,
    updateReadingSettings,
  };
};