import { useState, useEffect } from 'react';
import { Book, ReadingGoal } from '../types/Book';

const PROGRESS_KEY = 'digital-library-progress';
const GOALS_KEY = 'digital-library-goals';

export const useReadingProgress = () => {
  const [readingGoals, setReadingGoals] = useState<ReadingGoal[]>([]);

  useEffect(() => {
    loadGoals();
  }, []);

  const loadGoals = () => {
    try {
      const stored = localStorage.getItem(GOALS_KEY);
      if (stored) {
        setReadingGoals(JSON.parse(stored));
      } else {
        // Create default goals
        const defaultGoals: ReadingGoal[] = [
          {
            id: 'daily-reading',
            type: 'daily',
            target: 30,
            current: 0,
            unit: 'minutes',
            startDate: new Date().toISOString(),
            endDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
          },
          {
            id: 'monthly-books',
            type: 'monthly',
            target: 2,
            current: 0,
            unit: 'books',
            startDate: new Date().toISOString(),
            endDate: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).toISOString(),
          },
        ];
        setReadingGoals(defaultGoals);
        localStorage.setItem(GOALS_KEY, JSON.stringify(defaultGoals));
      }
    } catch (error) {
      console.error('Error loading goals:', error);
    }
  };

  const updateReadingProgress = (bookId: string, currentPage: number, totalPages: number) => {
    const progress = {
      currentPage,
      totalPages,
      lastReadDate: new Date().toISOString(),
      isCompleted: currentPage >= totalPages,
      readingTime: 0, // This would be calculated based on reading session
    };

    // Update goals if book is completed
    if (progress.isCompleted) {
      const updatedGoals = readingGoals.map(goal => {
        if (goal.unit === 'books') {
          return { ...goal, current: goal.current + 1 };
        }
        return goal;
      });
      setReadingGoals(updatedGoals);
      localStorage.setItem(GOALS_KEY, JSON.stringify(updatedGoals));
    }

    return progress;
  };

  const getTodaysProgress = () => {
    const today = new Date().toDateString();
    const dailyGoal = readingGoals.find(g => g.type === 'daily' && g.unit === 'minutes');
    return {
      goal: dailyGoal?.target || 30,
      current: dailyGoal?.current || 0,
      percentage: dailyGoal ? (dailyGoal.current / dailyGoal.target) * 100 : 0,
    };
  };

  return {
    readingGoals,
    updateReadingProgress,
    getTodaysProgress,
  };
};