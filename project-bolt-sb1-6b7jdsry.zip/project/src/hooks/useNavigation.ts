import { useState, useCallback } from 'react';
import { PageType, NavigationState } from '../types/Navigation';

export const useNavigation = () => {
  const [navigationState, setNavigationState] = useState<NavigationState>({
    currentPage: 'for-you',
    isTransitioning: false,
  });

  const navigateTo = useCallback((page: PageType) => {
    if (page === navigationState.currentPage) return;

    setNavigationState(prev => ({
      ...prev,
      isTransitioning: true,
    }));

    setTimeout(() => {
      setNavigationState({
        currentPage: page,
        previousPage: navigationState.currentPage,
        isTransitioning: false,
      });
    }, 150);
  }, [navigationState.currentPage]);

  return {
    currentPage: navigationState.currentPage,
    isTransitioning: navigationState.isTransitioning,
    navigateTo,
  };
};