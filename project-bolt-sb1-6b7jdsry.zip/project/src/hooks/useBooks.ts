import { useState, useEffect } from 'react';
import { Book } from '../types/Book';

const STORAGE_KEY = 'digital-library-books';

export const useBooks = () => {
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadBooks();
  }, []);

  const loadBooks = () => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        setBooks(JSON.parse(stored));
      }
    } catch (error) {
      console.error('Error loading books:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveBooks = (newBooks: Book[]) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newBooks));
      setBooks(newBooks);
    } catch (error) {
      console.error('Error saving books:', error);
      alert('Error saving book. Storage might be full.');
    }
  };

  const addBook = (book: Book) => {
    const newBooks = [...books, book];
    saveBooks(newBooks);
  };

  const removeBook = (id: string) => {
    const newBooks = books.filter(book => book.id !== id);
    saveBooks(newBooks);
  };

  const updateBook = (id: string, updates: Partial<Book>) => {
    const newBooks = books.map(book => 
      book.id === id ? { ...book, ...updates } : book
    );
    saveBooks(newBooks);
  };

  return {
    books,
    loading,
    addBook,
    removeBook,
    updateBook,
  };
};