export type PageType = 'for-you' | 'explore' | 'library' | 'settings';

export interface NavigationState {
  currentPage: PageType;
  previousPage?: PageType;
  isTransitioning: boolean;
}