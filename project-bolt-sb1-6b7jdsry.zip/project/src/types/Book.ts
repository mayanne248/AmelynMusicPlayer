export interface Book {
  id: string;
  title: string;
  author?: string;
  uploadDate: string;
  fileData: string; // base64 encoded PDF
  coverImage?: string; // base64 encoded image from first page
  pageCount?: number;
  fileSize: number;
  genre?: string;
  description?: string;
  rating?: number;
  tags?: string[];
  readingProgress?: {
    currentPage: number;
    totalPages: number;
    lastReadDate: string;
    isCompleted: boolean;
    readingTime: number; // in minutes
  };
  isFavorite?: boolean;
}

export interface UserSettings {
  profile: {
    name: string;
    email: string;
    profilePicture?: string;
    joinDate: string;
  };
  reading: {
    fontSize: number;
    fontFamily: string;
    backgroundColor: string;
    textColor: string;
    lineHeight: number;
    pageTransition: 'slide' | 'fade' | 'none';
    autoSave: boolean;
    nightMode: boolean;
  };
  notifications: {
    readingReminders: boolean;
    newBookAlerts: boolean;
    goalReminders: boolean;
    emailNotifications: boolean;
  };
  privacy: {
    shareReadingActivity: boolean;
    allowRecommendations: boolean;
    dataCollection: boolean;
  };
  goals: {
    dailyReadingMinutes: number;
    monthlyBookTarget: number;
    yearlyBookTarget: number;
  };
}

export interface ReadingGoal {
  id: string;
  type: 'daily' | 'weekly' | 'monthly' | 'yearly';
  target: number;
  current: number;
  unit: 'books' | 'pages' | 'minutes';
  startDate: string;
  endDate: string;
}