import React, { useState } from 'react';
import { useBooks } from './hooks/useBooks';
import { useNavigation } from './hooks/useNavigation';
import { useSettings } from './hooks/useSettings';
import { useReadingProgress } from './hooks/useReadingProgress';
import { Navigation } from './components/Navigation';
import { ForYouPage } from './components/pages/ForYouPage';
import { ExplorePage } from './components/pages/ExplorePage';
import { LibraryPage } from './components/pages/LibraryPage';
import { SettingsPage } from './components/pages/SettingsPage';
import { PDFViewer } from './components/PDFViewer';
import { Book } from './types/Book';

function App() {
  const { books, loading, addBook, removeBook, updateBook } = useBooks();
  const { currentPage, isTransitioning, navigateTo } = useNavigation();
  const { settings, updateSettings, updateProfile } = useSettings();
  const { updateReadingProgress } = useReadingProgress();
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);

  const handleDeleteBook = (id: string) => {
    if (window.confirm('Are you sure you want to delete this book?')) {
      removeBook(id);
    }
  };

  const handleOpenBook = (book: Book) => {
    setSelectedBook(book);
  };

  const handleUpdateReadingProgress = (bookId: string, currentPage: number, totalPages: number) => {
    const progress = updateReadingProgress(bookId, currentPage, totalPages);
    updateBook(bookId, { readingProgress: progress });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-100 flex items-center justify-center">
        <div className="flex flex-col items-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-amber-600 mb-4"></div>
          <p className="text-gray-600">Loading your library...</p>
        </div>
      </div>
    );
  }

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'for-you':
        return (
          <ForYouPage
            books={books}
            onOpenBook={handleOpenBook}
            onDeleteBook={handleDeleteBook}
          />
        );
      case 'explore':
        return (
          <ExplorePage
            books={books}
            onOpenBook={handleOpenBook}
            onDeleteBook={handleDeleteBook}
          />
        );
      case 'library':
        return (
          <LibraryPage
            books={books}
            onAddBook={addBook}
            onOpenBook={handleOpenBook}
            onDeleteBook={handleDeleteBook}
          />
        );
      case 'settings':
        return (
          <SettingsPage
            settings={settings}
            onUpdateSettings={updateSettings}
            onUpdateProfile={updateProfile}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-100 flex">
      {/* Sidebar Navigation */}
      <Navigation
        currentPage={currentPage}
        onNavigate={navigateTo}
        profilePicture={settings.profile.profilePicture}
        userName={settings.profile.name}
      />

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <div className={`transition-opacity duration-300 ${isTransitioning ? 'opacity-0' : 'opacity-100'}`}>
          <div className="max-w-7xl mx-auto px-6 py-8">
            {renderCurrentPage()}
          </div>
        </div>
      </main>

      {/* PDF Viewer */}
      {selectedBook && (
        <PDFViewer
          book={selectedBook}
          onClose={() => setSelectedBook(null)}
          onUpdateProgress={handleUpdateReadingProgress}
          settings={settings.reading}
        />
      )}
    </div>
  );
}

export default App;